<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php $this->load->view('partials/header'); ?>
		<ul class="breadcrumb">
			<div class="container-fluid">
				<li class="breadcrumb-item"><a href="<?php echo base_url('dashboard');?>">Home</a></li>
				<li class="breadcrumb-item active">Offer</li>
			</div>
		</ul>
		 <section class="feeds">
            <div class="container-fluid">
              <div class="row">
                
                
                <div class="restpassword">
                <div class="content">
                  
                  
                  
                  <div class="text-center">
                  <h4><i class="fa fa-lock fa-4x"></i></h4>
                  <h4 class="text-center">Change Password?</h4>
                  <p>You can reset your password here.</p>
                  <div class="panel-body">
    
                    <form id="register-form" role="form" autocomplete="off" class="form" method="post">
    
                      <div class="form-group">
                        <div class="input-group">
                         <div class="col-md-5">
                          <label>
                           Current Password
                          </label></div>
                           <div class="col-md-7">
                          <input id="email" name="email" placeholder="password" class="form-control" type="email">
                        </div>
                      </div> </div>
                      
                      <div class="form-group">
                        <div class="input-group">
                          <div class="col-md-5">
                            <label>
                             New Password
                           </label></div>
                            <div class="col-md-7">
                          <input id="email" name="email" placeholder="new password" class="form-control" type="email">
                        </div>
                      </div> </div>
                      
                      <div class="form-group">
                        <div class="input-group">
                          <div class="col-md-5">
                              <label>
                               Confirm Password
                               </label></div>
                           <div class="col-md-7">
                          <input id="email" name="email" placeholder="confirm password" class="form-control" type="email">
                          
                           </div>
                        </div>
                      </div>
                      
                      
                      <div class="form-group">
                        <input name="recover-submit" class="btn btn-lg btn-primary rest" value="Reset Password" type="submit">
                      </div>
                      
                     
                    </form>
    
                  </div>
                </div>
                </div>
                </div>
              </div>
            </div>
          </section>
     <?php $this->load->view('partials/footer'); ?>