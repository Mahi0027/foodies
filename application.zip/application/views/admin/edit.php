<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<?php $this->load->view('admin/header'); ?>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <?php
        if($users){
        foreach ($users as $key => $row) {
        ?>
        <li class="breadcrumb-item">
          <a href="<?php echo base_url('admin/dashboard'); ?>">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Edit <?php echo $row['first_name']." ".$row['middle_name']." ".$row['last_name'] ?>'s Details</li>
      </ol>
      <form action="<?php echo base_url('admin/dashboard/edit')?>" method="post">
        
          <div class="form-group">
            <input class="form-control form-control-sm" name="customer_id" type="hidden" value="<?php echo $row['customer_id']; ?>" fixed>
        </div>
          <div class="form-group">
            <label>First Name :</label>
            <input class="form-control form-control-sm" name="first_name" type="text" value="<?php echo $row['first_name']; ?>">
        </div>
        <div class="form-group">
            <label>Middle Name :</label>
            <input class="form-control form-control-sm" name="middle_name" type="text" value="<?php echo $row['middle_name']; ?>">
        </div>
        <div class="form-group">
            <label>Last Name :</label>
            <input class="form-control form-control-sm" name="last_name" type="text" value="<?php echo $row['last_name']; ?>">
        </div>
        <div class="form-group">
            <label>Date of Birth :</label>
            <input type="date" class="form-control form-control-sm " name="dob">
          </div>
          <div class="form-group">
            <label>geneder :</label>
            <div class="form-check-inline">
                <label class="form-check-label">
                    <input type="radio" class="form-check-input" name="gender" value="male">Male
                  </label>
            </div>&emsp;&emsp;&emsp;
            <div class="form-check-inline">
              <label class="form-check-label">
                <input type="radio" class="form-check-input" name="gender" value="female">Female
              </label>
            </div>
          </div>
        <div class="form-group">
            <label>Mobile Number :</label>
            <input class="form-control form-control-sm" name="mobile_no" type="text" value="<?php echo $row['mobile_no']; ?>">
        </div>
        <button type="submit" class="btn  btn-success" name="update">Update</button>
      </form>
      <?php
        }
      }
      ?>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © Your Website 2018</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="<?php echo base_url('admin/login/logout'); ?>">Logout</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php $this->load->view('admin/footer'); ?>