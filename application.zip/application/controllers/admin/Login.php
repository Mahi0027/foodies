<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	 public function __construct()
	 {
		parent::__construct();
		 $this->load->database();
		$this->load->model("Common_model"); 
		$this->load->library('form_validation');
		$this->load->library("session");    		
	}
		
	public function index()
	{
		
		$user_id = $this->session->userdata('restaurant_id');
		if(isset($user_id)):
			redirect('/dashboard');
		   return TRUE; 
		endif;
		$this->load->view('admin/login');
	}
	
	public function ajax_signup()
	{
		
		$op=$status= $error= array();
		// Validation code
		$this->form_validation->set_rules('Username', 'Username', 'trim|required',array('required' => 'You must provide a %s.'));
		$this->form_validation->set_rules('Password', 'Password', 'trim|required', array('required' => 'You must provide a %s.'));
		
		
		$data_array =  array('restaurant_owner_email'=>$this->input->post('Username'),
								 'password'=>$this->input->post('Password'));
		$data=$this->Common_model->select_info('t_restaurant',array('restaurant_owner_email'=>$this->input->post('Username'),'password'=>$this->input->post('Password')));	
		print_r($data[0]['status']);	

		if($data[0]['status']==1){
			//is_unique check the unique email value in users table

			if ($this->form_validation->run() == TRUE):
				 $data_array =  array('restaurant_owner_email'=>$this->input->post('Username'),
									 'password'=>$this->input->post('Password'));
				 
				   $responce = $this->Common_model->select_info('t_restaurant',$data_array);
		             	             
					if($responce ==  FALSE):

					$this->session->set_flashdata('message',"Please check  your credentials") ;  
					redirect('/admin/login/');
					
					elseif(count($responce) > 0):
						$data_array =  array(
								'restaurant_id'=> $responce[0]['restaurant_id'],
								'restaurant_email'=>$responce[0]['restaurant_owner_email']
						);
						$this->session->set_userdata($data_array);
						
						redirect('/admin/dashboard/');
						
					
				 endif;
				 
			else :
				
				$error['username'] = form_error('loginUsername');
				$error['password'] = form_error('loginPassword');

				$this->session->set_flashdata('message',"Please enter username ans password") ;
				redirect('/admin/login/');  
				
			endif;
		}
		else{
			$this->session->set_flashdata('message',"Your ID is inactive plz contact to admin");
			redirect('/admin/login/'); 
		}
		
	
	}
        
    public function logout() {
        $this->session->sess_destroy();
        redirect('admin/login');
     }
}
