<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	 public function __construct()
	 {
		parent::__construct();
		 $this->load->database();
		$this->load->model("Common_model"); 
		$this->load->library('form_validation');
		$this->load->library("session");    		
	}
		
	public function index()
	{
		$user_id = $this->session->userdata('restaurant_id');
		if(!isset($user_id)):
			redirect('/admin/login');
		   return TRUE; 
		endif;

		$this->load->view('admin/dashboard/user_list');
	}

	public function userlist(){
		$data = array();

		$data['users']  = $this->Common_model->select_info('t_basic_details');
		$this->load->view('admin/userlist',$data);	
	}
	

	public function useradd(){
		$user_id = $this->session->userdata('restaurant_id');
		if(!isset($user_id)):
			redirect('/admin/login');
		   return TRUE; 
		endif;
		$this->load->view('admin/useradd');
	}

	public function useraddrow(){
		$user_id = $this->session->userdata('restaurant_id');
		if(!isset($user_id)):
			redirect('/admin/login');
		   return TRUE; 
		endif;
		$first_name=$this->input->post('first_name');
		$middle_name=$this->input->post('middle_name');
		$last_name=$this->input->post('last_name');
		$email=$this->input->post('email');
		$password=$this->input->post('password');
		$dob=$this->input->post('dob');
		$gender=$this->input->post('gender');
		$mobile_no=$this->input->post('mobile_no');
		$refer_code=$this->input->post('refer_code');
		$refer_by=$this->input->post('refer_by');
		$marital_status=$this->input->post('marital_status');
		$address=$this->input->post('address');
		$state=$this->input->post('state');
		$city=$this->input->post('city');
		$pincode=$this->input->post('pincode');

		$result=$this->Common_model->insert_info('t_basic_details',array('email_id'=>$email,'first_name'=>$first_name,'middle_name'=>$middle_name,'last_name'=>$last_name,'dob'=>$dob,'gender'=>$gender,'mobile_no'=>$mobile_no,'refer_code'=>$refer_code,'refer_by'=>$refer_by,'password'=>$password,'marital_status'=>$marital_status,'address'=>$address,'state'=>$state,'city'=>$city,'pincode'=>$pincode));
		if($result==TRUE){
			redirect('admin/dashboard/userlist');
		}

	}
	public function user_row_delete($row){
		$result=$this->Common_model->delete_info('t_basic_details',array('customer_id'=>$row));
		if($result==true){
			redirect('admin/dashboard/userlist/'.$row);
		}
		else{
			//redirect('admin/dashboard/userlist/.'$row);
		}
	}

	public function user_row($id){
		$row=$id;
		$data=array();
		$data['users']=$this->Common_model->select_info('t_basic_details',array('customer_id'=>$row));
		if($data==TRUE){
			$this->load->view('admin/edit_user_data',$data);
		}
	}
        
    public function update_user_data(){
    	$first_name=$this->input->post('first_name');
    	$middle_name=$this->input->post('middle_name');
    	$last_name=$this->input->post('last_name');
    	$dob=$this->input->post('dob');
    	$gender=$this->input->post('gender');
    	$mobile_no=$this->input->post('mobile_no');
    	$row=$this->input->post('customer_id');
    	$result=$this->Common_model->update_info('t_basic_details',array('first_name'=>$first_name,'middle_name'=>$middle_name,'last_name'=>$last_name,'dob'=>$dob,'gender'=>$gender,'mobile_no'=>$mobile_no),array('customer_id'=>$row));
    	if(result==TRUE){
    		redirect('admin/dashboard/user_list'	);
    	}
    	else{
    		redirect('admin/dashboard/userlist');
    	}
    }

	public function userdatashow($id){
		$user_id = $this->session->userdata('restaurant_id');
		if(!isset($user_id)):
			redirect('/admin/login');
		   return TRUE; 
		endif;

		$data=array();
		$data['userdata']=$this->Common_model->select_info('t_basic_details',array('customer_id'=>$id));
		$this->load->view('admin/userdatashow',$data);
	}

	public function status_update($status,$id){
		$result=$this->Common_model->update_info('t_basic_details',array('status'=>$status),array('customer_id'=>$id));
		if($result==TRUE){
			redirect('admin/dashboard/userlist');
		}
	}

    public function logout() {
        $this->session->sess_destroy();
        redirect('login');
     }
}
