<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url('assets/admin/');?>vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url('assets/admin/');?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url('assets/admin/');?>vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url('assets/admin/');?>vendor/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url('assets/admin/');?>vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url('assets/admin/');?>vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url('assets/admin/');?>js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="<?php echo base_url('assets/admin/');?>js/sb-admin-datatables.min.js"></script>
    <script src="<?php echo base_url('assets/admin/');?>js/sb-admin-charts.min.js"></script>
  </body>

</html>
