<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<footer class="main-footer">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-6">
              <p>Your company &copy; 2017-2018</p>
            </div>
            <div class="col-sm-6 text-right">
              <p>Design by <a href="http://ascentcybersolutions.com/" class="external">Ascent Cyber Solutions</a></p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </div>
</div>
<script src="<?php echo base_url('assets/js/jquery.min.js');?>"></script> 
<script src="<?php echo base_url('assets/js/tether.min.js');?>"></script> 
<script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script> 
<script src="<?php echo base_url('assets/js/jquery.cookie.js');?>"> </script> 
<script src="<?php echo base_url('assets/js/jquery.validate.min.js');?>"></script> 
<script src="<?php echo base_url('assets/js/Chart.min.js');?>"></script> 
<script src="<?php echo base_url('assets/js/charts-home.js');?>"></script> 
<script src="<?php echo base_url('assets/js/front.js');?>"></script>
</body>
</html>