<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	 public function __construct()
	 {
		parent::__construct();
		 $this->load->database();
		$this->load->model("Common_model"); 
		$this->load->library('form_validation');
		$this->load->library("session");    		
	}
		
	public function index()
	{
		$user_id = $this->session->userdata('restaurant_id');
		if(!isset($user_id)):
			redirect('/admin/login');
		   return TRUE; 
		endif;

		$this->load->view('admin/dashboard');
	}
	public function userlist(){
		$data = array();

		$data['users']  = $this->Common_model->select_info('t_basic_details');
		$this->load->view('admin/userlist',$data);	
	}
	
	public function ajax_signup()
	{
		
		$op=$status= $error= array();
		// Validation code
		$this->form_validation->set_rules('Username', 'Username', 'trim|required',array('required' => 'You must provide a %s.'));
		$this->form_validation->set_rules('Password', 'Password', 'trim|required', array('required' => 'You must provide a %s.'));
		
		//is_unique check the unique email value in users table
	
		if ($this->form_validation->run() == TRUE):
			 $data_array =  array('restaurant_owner_email'=>$this->input->post('Username'),
								 'password'=>$this->input->post('Password'));
			 
			   $responce = $this->Common_model->select_info('t_restaurant',$data_array);
	             	             
				if($responce ==  FALSE):

				$this->session->set_flashdata('message',"Please check  your credentials") ;  
				redirect('/admin/login/');
				
				elseif(count($responce) > 0):
					$data_array =  array(
							'restaurant_id'=> $responce[0]['restaurant_id'],
							'restaurant_email'=>$responce[0]['restaurant_owner_email']
					);
					$this->session->set_userdata($data_array);
					
					redirect('/admin/dashboard/');
					
				
			 endif;
			 
		else :
			
			$error['username'] = form_error('loginUsername');
			$error['password'] = form_error('loginPassword');

			$this->session->set_flashdata('message',"Please enter username and password") ;
			redirect('/admin/login/');  
			
		endif;
		
		
	}

	public function useradd(){
		$user_id = $this->session->userdata('restaurant_id');
		if(!isset($user_id)):
			redirect('/admin/login');
		   return TRUE; 
		endif;
		$this->load->view('admin/useradd');
	}
	public function useraddrow(){
		$user_id = $this->session->userdata('restaurant_id');
		if(!isset($user_id)):
			redirect('/admin/login');
		   return TRUE; 
		endif;
		$first_name=$this->input->post('first_name');
		$middle_name=$this->input->post('middle_name');
		$last_name=$this->input->post('last_name');
		$email=$this->input->post('email');
		$password=$this->input->post('password');
		$dob=$this->input->post('dob');
		$gender=$this->input->post('gender');
		$mobile_no=$this->input->post('mobile_no');
		$refer_code=$this->input->post('refer_code');
		$refer_by=$this->input->post('refer_by');
		$marital_status=$this->input->post('marital_status');
		$address=$this->input->post('address');
		$state=$this->input->post('state');
		$city=$this->input->post('city');
		$pincode=$this->input->post('pincode');

		$result=$this->Common_model->insert_info('t_basic_details',array('email_id'=>$email,'first_name'=>$first_name,'middle_name'=>$middle_name,'last_name'=>$last_name,'dob'=>$dob,'gender'=>$gender,'mobile_no'=>$mobile_no,'refer_code'=>$refer_code,'refer_by'=>$refer_by,'password'=>$password,'marital_status'=>$marital_status,'address'=>$address,'state'=>$state,'city'=>$city,'pincode'=>$pincode));
		if($result==TRUE){
			//$this->load->view('admin/userlist');
			redirect('admin/dashboard/userlist');
		}
		//$this->load->view('admin/userlist');

	}
	public function restodelete($row){
		$result=$this->Common_model->delete_info('t_basic_details',array('customer_id'=>$row));
		if($result==true){
			redirect('admin/dashboard/userlist/'.$row);
		}
		else{
			//redirect('admin/dashboard/userlist/.'$row);
		}
	}

	public function restoedit($id){
		$row=$id;
		$data=array();
		$data['users']=$this->Common_model->select_info('t_basic_details',array('customer_id'=>$row));
		if($data==TRUE){
			$this->load->view('admin/edit',$data);
		}
	}

        
    public function edit(){
    	$first_name=$this->input->post('first_name');
    	$middle_name=$this->input->post('middle_name');
    	$last_name=$this->input->post('last_name');
    	$dob=$this->input->post('dob');
    	$gender=$this->input->post('gender');
    	$mobile_no=$this->input->post('mobile_no');
    	$row=$this->input->post('customer_id');
    	$result=$this->Common_model->update_info('t_basic_details',array('first_name'=>$first_name,'middle_name'=>$middle_name,'last_name'=>$last_name,'dob'=>$dob,'gender'=>$gender,'mobile_no'=>$mobile_no),array('customer_id'=>$row));
    	if(result==TRUE){
    		redirect('admin/dashboard/userlist'	);
    	}
    	else{
    		redirect('admin/dashboard/userlist');
    	}
    }

	public function user_detail_show($id){
		$user_id = $this->session->userdata('restaurant_id');
		if(!isset($user_id)):
			redirect('/admin/login');
		   return TRUE; 
		endif;

		$data=array();
		$data['userdata']=$this->Common_model->select_info('t_basic_details',array('customer_id'=>$id));
		$this->load->view('admin/user_detail_show',$data);
	}

	public function status_update($status,$id){
		$result=$this->Common_model->update_info('t_basic_details',array('status'=>$status),array('customer_id'=>$id));
		if($result==TRUE){
			redirect('admin/dashboard/userlist');
		}
	}

    public function logout() {
        $this->session->sess_destroy();
        redirect('login');
    }





    public function restaurant_complete_detail($id)
    {
    	$user_id = $this->session->userdata('restaurant_id');
		if(!isset($user_id)):
			redirect('/admin/login');
		   return TRUE; 
		endif;

		$data=array();
		$data['userdata']=$this->Common_model->select_info('t_restaurant',array('restaurant_id'=>$id));
    	$this->load->view('admin/restaurant_complete_detail',$data);
    }
}
